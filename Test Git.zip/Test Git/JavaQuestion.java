package Test;

public class Testuestion{

	public static void main(String[] args) {

		int a = 12323;
		int b = 34353;
		
		System.out.println("Numbers before Swap: " + a + " and " + b);
		
		a = a + b;
		b = a - b;
		a = a - b;
		
		System.out.println("Numbers after Swap: " + a + " and " + b);
		
	}

}
